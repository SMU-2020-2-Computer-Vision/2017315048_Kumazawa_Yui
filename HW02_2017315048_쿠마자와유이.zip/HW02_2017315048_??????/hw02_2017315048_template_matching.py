import cv2
import numpy as np

def template_matching(img_template, img_reference):
    img_gray = cv2.cvtColor(img_reference, cv2.COLOR_BGR2GRAY)
    w, h = img_template.shape[::-1]
    res = cv2.matchTemplate(img_gray, img_template, cv2.TM_CCOEFF_NORMED)
    threshhold = 0.6
    loc = np.where(res >= threshhold)

    img_res = img_reference.copy()
    for pt in zip(*loc[::-1]):
        x = pt[0]+w
        y = pt[1]+h
        cv2.rectangle(img_res, pt, (x,y), (0,0,255), 2)

    cv2.imshow('result',img_res)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    return x, y
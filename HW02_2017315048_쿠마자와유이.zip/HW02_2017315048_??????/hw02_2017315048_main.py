import os
import cv2
from hw02_2017315048_template_matching import template_matching

cwd = os.path.dirname(os.path.abspath(__file__))
os.chdir(cwd)

img = cv2.imread('img/test_background.png')
template = cv2.imread('img/fish.png',0)

template_matching(template,img)